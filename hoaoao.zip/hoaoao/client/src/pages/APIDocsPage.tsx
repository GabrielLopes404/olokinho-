import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Code, Lock, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function APIDocsPage() {
  const [, setLocation] = useLocation();

  const endpoints = [
    { method: "GET", path: "/api/customers", description: "Listar clientes" },
    { method: "POST", path: "/api/customers", description: "Criar cliente" },
    { method: "GET", path: "/api/invoices", description: "Listar faturas" },
    { method: "POST", path: "/api/invoices", description: "Criar fatura" },
    { method: "GET", path: "/api/transactions", description: "Listar transações" },
    { method: "POST", path: "/api/transactions", description: "Criar transação" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
            Documentação da API
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            API REST completa para integrar o LUCREI em seus sistemas
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <Code className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="font-semibold mb-2">RESTful API</h3>
              <p className="text-sm text-muted-foreground">
                API REST padrão com JSON
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Lock className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="font-semibold mb-2">Autenticação Segura</h3>
              <p className="text-sm text-muted-foreground">
                API Keys com controle de permissões
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Zap className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="font-semibold mb-2">Rate Limiting</h3>
              <p className="text-sm text-muted-foreground">
                1000 requisições por minuto
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Endpoints Principais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {endpoints.map((endpoint, index) => (
                <div 
                  key={index}
                  className="flex items-center gap-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <Badge 
                    variant={endpoint.method === "GET" ? "secondary" : "default"}
                    className="w-16 justify-center"
                  >
                    {endpoint.method}
                  </Badge>
                  <code className="flex-1 text-sm font-mono">{endpoint.path}</code>
                  <span className="text-sm text-muted-foreground">{endpoint.description}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 border-purple-500/20">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Comece a integrar agora</h2>
            <p className="text-muted-foreground mb-6">
              Acesse a documentação completa e exemplos de código
            </p>
            <Button 
              onClick={() => setLocation("/register")}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-purple-400"
            >
              Obter API Key Gratuita
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
