import AccountsPage from "./AccountsPage";

export default function BankAccountsPage() {
  return <AccountsPage />;
}
