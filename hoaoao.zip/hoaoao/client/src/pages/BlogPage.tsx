import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, User } from "lucide-react";
import { motion } from "framer-motion";

export default function BlogPage() {
  const [, setLocation] = useLocation();

  const posts = [
    {
      title: "5 Dicas para Melhorar seu Fluxo de Caixa",
      excerpt: "Descubra estratégias essenciais para manter sua empresa sempre saudável financeiramente.",
      category: "Gestão Financeira",
      date: "15 Mar 2024",
      author: "Equipe LUCREI"
    },
    {
      title: "Como a Automação Pode Economizar Horas de Trabalho",
      excerpt: "Entenda como automatizar processos financeiros pode transformar sua rotina.",
      category: "Produtividade",
      date: "10 Mar 2024",
      author: "Equipe LUCREI"
    },
    {
      title: "LGPD na Gestão Financeira: O que Você Precisa Saber",
      excerpt: "Guia completo sobre conformidade com a Lei Geral de Proteção de Dados.",
      category: "Segurança",
      date: "5 Mar 2024",
      author: "Equipe LUCREI"
    }
  ];

  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent break-words">
            Blog LUCREI
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Insights, dicas e novidades sobre gestão financeira
          </p>
        </motion.div>

        <div className="space-y-6">
          {posts.map((post, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Badge variant="secondary">{post.category}</Badge>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold mb-3 break-words">{post.title}</h2>
                  <p className="text-muted-foreground mb-4 line-clamp-2">{post.excerpt}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      <span>{post.author}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-12"
        >
          <p className="text-muted-foreground mb-4">Quer ficar por dentro das novidades?</p>
          <Button 
            variant="outline"
            onClick={() => setLocation("/register")}
          >
            Inscreva-se Gratuitamente
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
