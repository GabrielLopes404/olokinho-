import { parse } from 'csv-parse/sync';
import { z } from 'zod';

export interface CSVTransactionRow {
  date: string;
  description: string;
  amount: string;
  type: 'income' | 'expense';
  category?: string;
  bankAccount?: string;
  costCenter?: string;
  notes?: string;
}

const csvTransactionSchema = z.object({
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Data inválida",
  }),
  description: z.string().min(1, "Descrição obrigatória"),
  amount: z.string().refine((val) => !isNaN(parseFloat(val)), {
    message: "Valor inválido",
  }),
  type: z.enum(['income', 'expense'], {
    errorMap: () => ({ message: "Tipo deve ser 'income' ou 'expense'" }),
  }),
  category: z.string().optional(),
  bankAccount: z.string().optional(),
  costCenter: z.string().optional(),
  notes: z.string().optional(),
});

export interface ParsedTransaction {
  date: Date;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category?: string;
  bankAccount?: string;
  costCenter?: string;
  notes?: string;
}

export interface CSVParseResult {
  success: boolean;
  transactions: ParsedTransaction[];
  errors: Array<{
    row: number;
    errors: string[];
  }>;
}

export async function parseTransactionsCSV(
  csvContent: string,
  options: {
    delimiter?: string;
    skipEmptyLines?: boolean;
  } = {}
): Promise<CSVParseResult> {
  try {
    const records = parse(csvContent, {
      columns: true,
      skip_empty_lines: options.skipEmptyLines !== false,
      delimiter: options.delimiter || ',',
      trim: true,
      bom: true,
    });

    const transactions: ParsedTransaction[] = [];
    const errors: Array<{ row: number; errors: string[] }> = [];

    records.forEach((record: any, index: number) => {
      try {
        const validated = csvTransactionSchema.parse(record);
        
        transactions.push({
          date: new Date(validated.date),
          description: validated.description,
          amount: parseFloat(validated.amount),
          type: validated.type,
          category: validated.category,
          bankAccount: validated.bankAccount,
          costCenter: validated.costCenter,
          notes: validated.notes,
        });
      } catch (error) {
        if (error instanceof z.ZodError) {
          errors.push({
            row: index + 1,
            errors: error.errors.map(e => `${e.path.join('.')}: ${e.message}`),
          });
        } else {
          errors.push({
            row: index + 1,
            errors: ['Erro desconhecido ao processar linha'],
          });
        }
      }
    });

    return {
      success: errors.length === 0,
      transactions,
      errors,
    };
  } catch (error) {
    throw new Error(`Erro ao parsear CSV: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function generateCSVTemplate(): string {
  const headers = [
    'date',
    'description',
    'amount',
    'type',
    'category',
    'bankAccount',
    'costCenter',
    'notes'
  ];
  
  const example = [
    '2024-11-05',
    'Venda de produto',
    '1500.00',
    'income',
    'Vendas',
    'Conta Principal',
    'Vendas',
    'Primeira venda do mês'
  ];

  return headers.join(',') + '\n' + example.join(',');
}
