export function validateCPF(cpf: string): boolean {
  const cleaned = cpf.replace(/\D/g, "");
  
  if (cleaned.length !== 11) return false;
  if (/^(\d)\1+$/.test(cleaned)) return false;
  
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleaned.charAt(i)) * (10 - i);
  }
  let digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  if (digit !== parseInt(cleaned.charAt(9))) return false;

  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleaned.charAt(i)) * (11 - i);
  }
  digit = 11 - (sum % 11);
  if (digit >= 10) digit = 0;
  return digit === parseInt(cleaned.charAt(10));
}

export function validateCNPJ(cnpj: string): boolean {
  const cleaned = cnpj.replace(/\D/g, "");
  
  if (cleaned.length !== 14) return false;
  if (/^(\d)\1+$/.test(cleaned)) return false;

  let size = cleaned.length - 2;
  let numbers = cleaned.substring(0, size);
  const digits = cleaned.substring(size);
  let sum = 0;
  let pos = size - 7;

  for (let i = size; i >= 1; i--) {
    sum += parseInt(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }

  let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== parseInt(digits.charAt(0))) return false;

  size = size + 1;
  numbers = cleaned.substring(0, size);
  sum = 0;
  pos = size - 7;

  for (let i = size; i >= 1; i--) {
    sum += parseInt(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }

  result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  return result === parseInt(digits.charAt(1));
}

export function normalizeDocument(doc: string): string {
  return doc.replace(/\D/g, "");
}

export function validateDocument(document: string, personType: "PF" | "PJ"): { valid: boolean; message?: string } {
  if (!document) {
    return { valid: true }; // Document is optional
  }

  const normalized = normalizeDocument(document);
  
  if (personType === "PF") {
    if (!validateCPF(normalized)) {
      return { valid: false, message: "CPF inválido" };
    }
    if (normalized.length !== 11) {
      return { valid: false, message: "CPF deve ter 11 dígitos" };
    }
  } else if (personType === "PJ") {
    if (!validateCNPJ(normalized)) {
      return { valid: false, message: "CNPJ inválido" };
    }
    if (normalized.length !== 14) {
      return { valid: false, message: "CNPJ deve ter 14 dígitos" };
    }
  }

  return { valid: true };
}
